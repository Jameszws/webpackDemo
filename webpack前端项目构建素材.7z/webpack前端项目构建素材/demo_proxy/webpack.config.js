var path = require('path');
var webpack = require("webpack");

module.exports = {

    devtool: 'source-map',
    
    entry: {
        index:'./src/js/index.js'
    },
    
    output: {
        publicPath:"dev",
        path:path.resolve(__dirname,'dist'),
        filename: '[name].js'
    },

    resolve: { 
        extensions: ['.js'],
        alias: {
        }
    },

    devServer: {        
        historyApiFallback: true,   //不跳转
        inline: true,    //实时刷新
        port:8086,
        proxy:{
            "/endtoend-replace-service/api/pagehearderservice/json/*":{
                target: "http://ws.open.ctripcorp.com",
                changeOrigin: true
            }
        }
    },

    plugins:[
        new webpack.ProvidePlugin({
            $: "jquery",
            jQuery: "jquery",
            "window.jQuery": "jquery",            
        }),
    ]

};