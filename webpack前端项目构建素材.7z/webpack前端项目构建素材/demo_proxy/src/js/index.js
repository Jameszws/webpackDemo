
let indexController ={
    init(){
        document.write("this is proxy demo");
    },
    sendAjax(){
        $.ajax({
            //url:"http://ws.open.ctripcorp.com/endtoend-replace-service/api/pagehearderservice/json/getPageInfo",
            url:"/endtoend-replace-service/api/pagehearderservice/json/getPageInfo",
            type:"GET",
            data:{},
            success:(ret)=>{
                console.log(ret);
            }
        });
    }
};

indexController.init();
indexController.sendAjax();


