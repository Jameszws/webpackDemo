var path = require('path');
var webpack = require('webpack');

module.exports = {
        
    entry: {
        index:'./src/js/index.js'
    },
    
    output: {
        path:path.resolve(__dirname,'dist'),
        filename: '[name].js'
    },

    module:{
        loaders:[
            { test:/\.js$/,loader:"./src/loader/test-loader"},
            { test:/\.tpl.html$/,loader:"./src/loader/html-template-loader"},
        ]
    },

    plugins:[
        
    ]
};