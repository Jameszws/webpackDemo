
var _ = require("lodash");

function HtmlTemplateLoader(source){
    var template = _.template(source);
    
    return "module.exports=" + template;
};

module.exports = HtmlTemplateLoader;
