
function TestLoader(source){
    console.log("this is test loader");
    return source;
};
module.exports = TestLoader;