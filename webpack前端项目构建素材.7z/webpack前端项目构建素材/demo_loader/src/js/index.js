import _ from "lodash";
import templ from "../template/index.tpl.html";

const data = [
    {name:"张一"},{name:"张二"},{name:"张三"},
    {name:"张四"},{name:"张五"},
];

var index = {
    init(){
        var html = "this is webpack loader demo";
        document.write(html);
    },

    renderTmpl(){
        var ss =templ({data:data});
        alert(ss);
    }
};

index.init();
index.renderTmpl();


