var path = require('path');

module.exports = {

    devtool: 'source-map',
    
    entry: {
        index:'./src/js/index.js'
    },
    
    output: {
        publicPath:"dev",
        path:path.resolve(__dirname,'dist'),
        filename: '[name].js'
    },

    module:{
        loaders:[
            { test:/\.js$/,loader:"./src/loader/test-loader"},
            { test:/\.tpl.html$/,loader:"./src/loader/html-template-loader"},
        ]
    },

    devServer: {        
        historyApiFallback: true,   //不跳转
        inline: true,    //实时刷新
        port:8080
    }
 
};