var path = require('path');
var HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {

    devtool: 'source-map',
    
    entry: {
        index:'./src/js/index.js'
    },
    
    output: {
        publicPath:"dev",
        path:path.resolve(__dirname,'dist'),
        filename: '[name].js'
    },

    devServer: {
        //contentBase: "./src/views/",    //本地服务器所加载的页面所在的目录
        historyApiFallback: true,   //不跳转
        inline: true,    //实时刷新
        port:8080
    }
 
};