/*
* 创建 ReadMe.md 插件
*/
class ReadMePlugin {
    
    constructor(options){        
    }

    apply (compiler) {
        compiler.plugin('emit', function(compilation, callback) {            
            var filelist = ' ReadMe:\n\n';
            
            for (var filename in compilation.assets) {
                filelist += ('-- '+ filename +'\n');
            }

            // Insert this list into the webpack build as a new file asset:
            compilation.assets['ReadMe.md'] = {
                source: function() {
                    return filelist;
                },
                size: function() {
                    return filelist.length;
                }
            };

            callback();
        });
    };
}

module.exports = ReadMePlugin;