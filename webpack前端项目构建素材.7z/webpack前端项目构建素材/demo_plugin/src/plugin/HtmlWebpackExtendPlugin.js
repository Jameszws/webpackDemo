/*
*  扩展 HtmlWebpackPlugin 自定义插件
*/
function HtmlWebpackExtendPlugin(options) {
    this.options = options;
}

HtmlWebpackExtendPlugin.prototype.apply = function(compiler) {
    var paths = this.options.paths;
    compiler.plugin('compilation', function(compilation, options) {
        //htmlPluginData插入到html模板之前触发
        compilation.plugin('html-webpack-plugin-before-html-processing', function(htmlPluginData, callback) {
            for (var i = paths.length - 1; i >= 0; i--) {
                htmlPluginData.assets.js.unshift(paths[i]);
            }
            callback(null, htmlPluginData);
        });
    });
};

module.exports = HtmlWebpackExtendPlugin;
