
document.write("this is webpack demos");