var path = require('path');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var ReadMePlugin = require("./src/plugin/ReadMePlugin.js");
var HtmlWebpackExtendPlugin = require("./src/plugin/HtmlWebpackExtendPlugin.js");

module.exports = {
        
    entry: {
        index:'./src/js/index.js'
    },
    
    output: {
        publicPath:"../",
        path:path.resolve(__dirname,'dist'),
        filename: 'js/[name].js'
    },

    plugins:[
        new ReadMePlugin({}),

        new HtmlWebpackExtendPlugin({
            paths: ["./configuration/config.js"]
        }),

        new HtmlWebpackPlugin({ 
            filename:"views/index.html",
            template: './src/views/index.html',
            inject: 'body',
            chunks:["index"]
        }),
    ]
};