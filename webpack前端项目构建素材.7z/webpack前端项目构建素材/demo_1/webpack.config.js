const path = require('path');
const webpack = require('webpack');

module.exports = {

    devtool: 'source-map',
    
    entry: {
        index:'./src/js/index.js',
    },
    
    output: {
        publicPath:"dev",
        path:path.resolve(__dirname,'dist'),
        filename: '[name].js'
    },

    resolve: { 
        extensions: ['.js'],
        alias: {
            'cityData': path.join(__dirname, './src/static/cityData.js'), 
        }
    },

    devServer: {
        //contentBase: "./src/views/",    //本地服务器所加载的页面所在的目录
        historyApiFallback: true,   //不跳转
        inline: true,    //实时刷新
        port:8080
    },

    plugins:[
        //dll公共类库管理
        new webpack.DllReferencePlugin({
            context: __dirname,
            manifest: require('./manifest.json'),
        }),        
    ]

};