
const webpack = require('webpack');

const vendors = [
    './src/static/CityData.js'
    // ...其它库
];

module.exports = {
    entry: {
        "lib": vendors,
    },
    output: {
        path: __dirname + '/src/static/dev-libs',
        filename: '[name].js',
        library: '[name]',
    },
    plugins: [
        new webpack.DllPlugin({
            path: 'manifest.json',
            name: '[name]',
            context: __dirname,
        })        
    ],
};