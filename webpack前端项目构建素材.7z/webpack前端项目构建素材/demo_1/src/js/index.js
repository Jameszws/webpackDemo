import common from "./common.js";
import CityData from "cityData";

var indexDemo = {
    init(){
        document.write("this is webpack demo");
    }
};

indexDemo.init();