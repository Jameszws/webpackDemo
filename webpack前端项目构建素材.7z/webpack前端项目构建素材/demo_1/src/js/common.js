
var common = {
    func1(){
        alert("this is func1.");
    }
};

export default common;