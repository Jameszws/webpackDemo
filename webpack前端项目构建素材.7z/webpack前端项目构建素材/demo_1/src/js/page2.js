import common from "./common.js";

var page2 ={
    init(){
        console.log("this is page2");
    }
};

export default page2;