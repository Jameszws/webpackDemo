
var common2 = {
    func2(){
        alert("this is func222222222222.");
    }
};

export default common2;