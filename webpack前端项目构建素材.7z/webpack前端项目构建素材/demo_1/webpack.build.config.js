const path = require('path');
const webpack = require('webpack');

module.exports = {    
    
    entry: {
        index:'./src/js/index.js',
        page2:"./src/js/page2.js",
        vendor:["./src/js/common2.js"]
    },
    
    resolve: { 
        extensions: ['.js'],
        alias: {
            'cityData': path.join(__dirname, './src/static/cityData.js'),            
        }
    },

    output: {
        publicPath:"dev",
        path:path.resolve(__dirname,'dist'),
        filename: '[name].js'
    },

    devServer: {
        //contentBase: "./src/views/",    //本地服务器所加载的页面所在的目录
        historyApiFallback: true,   //不跳转
        inline: true,    //实时刷新
        port:8080
    },

    plugins:[        
        //new webpack.optimize.CommonsChunkPlugin("common"),
        new webpack.optimize.CommonsChunkPlugin({
            name:["qweqwe","tetst"],   //如果name在entry中存在，那么这个抽取的模块首先是包含enry中指定的js文件，然后再考虑包含抽取其他entry中的公用部分。
            filename:"[name].js",
            minChunks:2     //配置模块复用多少次以上进行抽取。
        })
    ]
};