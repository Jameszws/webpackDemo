var path = require('path');
var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
        
    entry: {
        index:'./src/js/index.js'
    },
    
    output: {        
        path:path.resolve(__dirname,'dist'),
        filename: '[name].js'
    },

    module:{
        loaders:[
        ]
    },

    plugins:[
        new HtmlWebpackPlugin({
            template:"./src/templates/templ.html",
            filename:"views/index.html",
            inject:"body"
        })
    ]
};