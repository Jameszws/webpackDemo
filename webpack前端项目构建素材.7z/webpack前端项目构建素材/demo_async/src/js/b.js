
class b {
    constructor(){

    }
    init (){
        console.log("this is b.js");
    }
}

module.exports = b;