

const b =require('./b');
new b().init();

require.ensure([], function (require) {
    const a = require('./a.js');
    new a().init();
});
