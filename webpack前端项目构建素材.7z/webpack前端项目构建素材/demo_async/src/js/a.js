
class a {
    constructor(){

    }
    init (){
        console.log("this is a.js");
    }
}

module.exports = a;