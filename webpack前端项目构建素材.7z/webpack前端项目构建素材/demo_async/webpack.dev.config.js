var path = require('path');

module.exports = {

    devtool: 'source-map',
    
    entry: {
        index:'./src/js/index.js'
    },
    
    output: {
        publicPath:"http://localhost:8080/",
        path:path.resolve(__dirname,'dist'),
        filename: '[name].js'
    },

    module:{
        loaders:[           
        ]
    },

    devServer: {        
        historyApiFallback: true,   //不跳转
        inline: true,    //实时刷新
        port:8080
    }
 
};